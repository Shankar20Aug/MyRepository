package com.myapp.ws.reporsitory;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.joda.time.LocalDate;

import com.myapp.ws.Order;

public class OrderRepository {

	private List<Order> list = new ArrayList<>();

	public OrderRepository() {


		list.add(new Order(111, "Apple", "IPhoneX2", 15000.00, "http://apple.com", LocalDate.now(), 4.5));

		list.add(new Order(222, "Apple", "IPhoneX2", 35000.00, "http://apple.com", LocalDate.now(), 1.5));

		list.add(new Order(333, "Samsung", "SamsungJ3", 8000.00, "http://samsung.com", LocalDate.now(), 2.5));
		
		list.add(new Order(444, "Samsung", "SamsungA2", 5000.00, "http://samsung.com", LocalDate.now(), 3.5));

	}
	
	public List<Order> searchRepository (String name) {
		return list.stream().filter(o -> o.getProductName().
				equalsIgnoreCase(name)).collect(Collectors.toList());
	}
}
